<!DOCTYPE html>
<html lang="en" class="dark">

@include('template.head')

<body>

    @include('template.sidebar')


    @include('template.header')
    
    @section('ca-dashboard')
    @show

    @include('template.footer')
</body>

</html>