<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>
                    <li class="label">Main</li>
                    <li class="active"><a class="sidebar-sub-toggle"><i class="ti-home"></i> Dashboard </a></li>
                    <li class="label">CA</li>
                    <li><a class="sidebar-sub-toggle" href="{!! url('company'); !!}"><i class="ti-pencil-alt"></i>Companies <span class="badge badge-primary">28</span></a>
                    </li>
                    
                    <li><a href="../documentation/index.html"><i class="ti-file"></i> Documentation</a></li>
                    <li><a><i class="ti-close"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /# sidebar -->