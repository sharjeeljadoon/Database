@extends('layouts.app')

@section('content')
    <div class="login-form">
        <h4>Administrator Login</h4>
        <form method="POST" action="{{ route('login') }}">
            {{ csrf_field() }}

            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                <label>Email address</label>
                <input id="email" type="email" placeholder="Email address" class="form-control text-color-white" name="email" value="{{ old('email') }}" required autofocus>

                @if ($errors->has('email'))
                <span class="help-block">
                    <strong>{{ $errors->first('email') }}</strong>
                </span>
                @endif
            </div>

            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                <label>Password</label>


                <input id="password" type="password" class="form-control text-color-white" name="password" placeholder="Password" required>

                @if ($errors->has('password'))
                <span class="help-block">
                    <strong>{{ $errors->first('password') }}</strong>
                </span>
                @endif

            </div>

            <div class="checkbox">
                <label>
                    <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Remember Me
                </label>
                <label class="pull-right">
                    <a href="#">Forgotten Password?</a>
                </label>

            </div>
            <button type="submit" class="btn btn-primary btn-flat m-b-30 m-t-30">Sign in</button>
            <div class="social-login-content">
                <div class="social-button">
                    <button type="button" class="btn btn-primary bg-facebook btn-flat btn-addon m-b-10"><i class="ti-facebook"></i>Sign in with facebook</button>
                    <button type="button" class="btn btn-primary bg-twitter btn-flat btn-addon m-t-10"><i class="ti-twitter"></i>Sign in with twitter</button>
                </div>
            </div>
            <div class="register-link m-t-15 text-center">
                <p>Don't have account ? <a href="{{ route('register') }}"> Sign Up Here</a></p>
            </div>
        </form>
    </div>
@endsection
