@extends('layouts.app')

@section('content')

    <div class="login-form">
        <h4>Register to Administration</h4>
        <form method="POST" action="{{ route('register') }}">
            {{ csrf_field() }}

            <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                <label>User Name</label>

                <input id="name" type="text" class="form-control text-color-white" placeholder="User Name" name="name" value="{{ old('name') }}" required autofocus>

                @if ($errors->has('name'))
                    <span class="help-block">
                        <strong>{{ $errors->first('name') }}</strong>
                    </span>
                @endif
            </div>

            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                <label>E-Mail Address</label>

                <input id="email" type="email" placeholder="Email" class="form-control text-color-white" name="email" value="{{ old('email') }}" required>

                @if ($errors->has('email'))
                <span class="help-block">
                    <strong>{{ $errors->first('email') }}</strong>
                </span>
                @endif
            </div>

            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                <label>Password</label>

                <input id="password" type="password" class="form-control text-color-white" placeholder="Password" name="password" required>

                @if ($errors->has('password'))
                <span class="help-block">
                    <strong>{{ $errors->first('password') }}</strong>
                </span>
                @endif
            </div>
            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                <label>Password</label>

                <input id="password-confirm" type="password" class="form-control text-color-white" name="password_confirmation" placeholder="Confirm Password" required>

                @if ($errors->has('password'))
                <span class="help-block">
                    <strong>{{ $errors->first('password') }}</strong>
                </span>
                @endif
            </div>


            <div class="checkbox">
                <label>
                    <input type="checkbox"> Agree the terms and policy 
                </label>
            </div>
            <button type="submit" class="btn btn-primary btn-flat m-b-30 m-t-30">Register</button>
            <div class="social-login-content">
                <div class="social-button">
                    <button type="button" class="btn btn-primary bg-facebook btn-flat btn-addon m-b-10"><i class="ti-facebook"></i>Register with facebook</button>
                    <button type="button" class="btn btn-primary bg-twitter btn-flat btn-addon m-t-10"><i class="ti-twitter"></i>Register with twitter</button>
                </div>
            </div>
            <div class="register-link m-t-15 text-center">
                <p>Already have account ? <a href="{{ route('login') }}"> Sign in</a></p>
            </div>
        </form>
    </div>
@endsection
