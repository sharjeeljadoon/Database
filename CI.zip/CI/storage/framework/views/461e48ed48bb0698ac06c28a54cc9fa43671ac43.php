<script src="<?php echo e(asset('assets/js/lib/jquery.min.js')); ?>"></script>
    <!-- jquery vendor -->
    <script src="<?php echo e(asset('assets/js/lib/jquery.nanoscroller.min.js')); ?>"></script>
    <!-- nano scroller -->
    <script src="<?php echo e(asset('assets/js/lib/menubar/sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/preloader/pace.min.js')); ?>"></script>
    <!-- sidebar -->
    <script src="<?php echo e(asset('assets/js/lib/bootstrap.min.js')); ?>"></script>
    <!-- bootstrap -->
    <script src="<?php echo e(asset('assets/js/lib/weather/jquery.simpleWeather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/weather/weather-init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/circle-progress/circle-progress-init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/chartist/chartist.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/chartist/chartist-init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/sparklinechart/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/sparklinechart/sparkline.init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/owl-carousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/owl-carousel/owl.carousel-init.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

    <!-- JS Grid Scripts Start-->
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/db.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/jsgrid.core.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/jsgrid.load-indicator.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/jsgrid.load-strategies.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/jsgrid.sort-strategies.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/jsgrid.field.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/fields/jsgrid.field.text.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/fields/jsgrid.field.number.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/fields/jsgrid.field.select.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/fields/jsgrid.field.checkbox.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/fields/jsgrid.field.control.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/lib/jsgrid/jsgrid-init.js')); ?>"></script>
    <!-- JS Grid Scripts End-->

    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>