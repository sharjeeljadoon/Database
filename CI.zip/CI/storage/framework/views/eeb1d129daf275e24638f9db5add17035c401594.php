<!DOCTYPE html>
<html lang="en" class="dark">

<?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

    <?php echo $__env->make('template.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <?php $__env->startSection('ca-dashboard'); ?>
    <?php echo $__env->yieldSection(); ?>

    <?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>