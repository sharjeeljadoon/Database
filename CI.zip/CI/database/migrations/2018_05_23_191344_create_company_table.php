<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCompanyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->increments('company_id');
            $table->integer('company_founder_id')->unsigned();
            $table->integer('company_investor_id')->unsigned();
            $table->integer('company_sosv_id')->unsigned();
            $table->integer('company_tag_id')->unsigned();
            $table->integer('company_corporation_id')->unsigned();
            $table->string('company_startup_name',45)->nullable();
            $table->string('company_funding',45)->nullable();
            $table->string('company_sosv',45)->nullable();
            $table->text('company_description')->nullable();
            $table->string('company_location',45)->nullable();
            $table->string('company_corporation',45)->nullable();
            $table->timestamps();
        });

        Schema::table('companies', function($table) {
            
            $table->foreign('company_founder_id')->references('founder_id')->on('founders')->onDelete('CASCADE');
            $table->foreign('company_investor_id')->references('investor_id')->on('investors')->onDelete('CASCADE');
            $table->foreign('company_sosv_id')->references('sosv_id')->on('sosv')->onDelete('CASCADE');
            $table->foreign('company_tag_id')->references('tag_id')->on('tags')->onDelete('CASCADE');
            $table->foreign('company_corporation_id')->references('corporation_id')->on('corporations')->onDelete('CASCADE');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
}
